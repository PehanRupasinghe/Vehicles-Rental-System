package sample;

public interface RentalVehicleManager {
    public abstract void addVehicle();
    public abstract void deleteVehicle();
    public abstract void printVehicle();
}
