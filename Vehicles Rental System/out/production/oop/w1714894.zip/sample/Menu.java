package sample;

import java.util.Scanner;

public class Menu {
    public static void main(String[] args) {
        Scanner myObject=new Scanner(System.in);
        String choose;
        int number=0;
        System.out.println("||ENTER 1 TO ADD VEHICLE, 2 TO DELETE VEHICLE OR 3 TO PRINT THE VEHICLE||");
        choose=myObject.nextLine();
        while (number==0){
            if (choose.equals("1")){
                addVehicle();
                number=1;
            }
            else if(choose.equals("2")){
                deleteVehicle();
                number=1;
            }
            else if(choose.equals("3")){
                printVehicle();
                number=1;
            }
            else{
                System.out.println("YOU HAVE CHOOSEN AN WRONG OPTION ");
            }
        }}
    static WestminsterRentalVehicleManager object;

    static { try {object = new WestminsterRentalVehicleManager();} catch (ClassNotFoundException b) { b.printStackTrace();}
    }

    public static void addVehicle(){object.addVehicle();}
    public static void deleteVehicle(){object.deleteVehicle();}
    public static void printVehicle(){object.printVehicle();}
}
