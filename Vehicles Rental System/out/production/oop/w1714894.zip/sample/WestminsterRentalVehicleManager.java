package sample;

import sample.RentalVehicleManager;


import java.sql.*;
import java.util.Scanner;
public class WestminsterRentalVehicleManager implements RentalVehicleManager {
    private Connection connect;
    private Statement state;
    private ResultSet rs;
    public WestminsterRentalVehicleManager() throws ClassNotFoundException {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/vehicle", "root", "");
            state = connect.createStatement();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void addVehicle() {
        int no1=0;
        int no2=0;
        int number = 0;
        boolean complete=true;
        String option="";
        Scanner sc = new Scanner(System.in);
        //usr input for options
        while (number == 0) {
            System.out.println("TO ADD A VEHICLE");
            System.out.println("ENTER 1 TO CAR OR 2 FOR MOTERBIKES");
            option=sc.nextLine();
            if ((option.equals("1")) || (option.equals("2"))){
                number=1;
            }
            else{
                System.out.println("invalid input");
            }
        }
        String query = "SELECT COUNT(*) FROM motorbike";
        String query5="SELECT COUNT(*) FROM car";
        try {
            rs = state.executeQuery(query);
            while(rs.next()){
                no1=rs.getInt(1);
            }
            rs = state.executeQuery(query5);
            while(rs.next()){
                no2=rs.getInt(1);
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        if(((no1+no2)<50) || (complete=true)) {
            //adding car information inside the car table in sql
            if (option.equals("1")){
                System.out.println("YOU ARE NOW ADDING A CAR");
                System.out.println("ENTER PLATE NUMBER");
                String plateNumber=sc.next();
                System.out.println("ENTER VEHICAL MODEL");
                String model=sc.next();
                System.out.println("ENTER VEHICAL MAKE");
                String make=sc.next();
                System.out.println("ENTER TYPE OF TRANSMISSION");
                String typeofTransmission=sc.next();
                System.out.println("ENTER THE VEHICLE YOU WANT IS RENTABLE OR NOT RENTABLE");
                String rentable=sc.next();
                System.out.println("ENTER NUMBER OF SEATS");
                int noofSeats=sc.nextInt();
                System.out.println("ENTER THE VEHICLE YOU WANT IS AIRBAGS OR NOT AIRBAGS");
                String airBags=sc.next();
                System.out.println("EENTER THE VEHICLE YOU WANT IS AIRCONDITION OR NOT AIRCONDITION");
                String airCondition=sc.next();
                Car car=new Car();
                car.setPlateNumber(plateNumber);
                car.setModel(model);
                car.setMake(make);
                car.settypeofTransmission(typeofTransmission);
                car.setrentable(rentable);
                car.setNoofSeats(noofSeats);
                car.setairBags(airBags);
                car.setairCondition(airCondition);
                try{
                    String query2 = "insert into car values(?,?,?,?,?,?,?,?)";
                    PreparedStatement insertState = connect.prepareStatement(query2);
                    insertState.setString(1, car.getPlateNumber());
                    insertState.setString(2, car.getMake());
                    insertState.setString(3,car.getModel());
                    insertState.setString(4,car.gettypeofTransmission());
                    insertState.setString(5,car.getrentable());
                    insertState.setInt(6,car.getNoofSeats());
                    insertState.setString(7,car.getairBags());
                    insertState.setString(8,car.getAirCondition());
                    insertState.executeUpdate();}
                catch (Exception ex){
                    ex.printStackTrace();
                }
            }
            if (option.equals("2")){
                System.out.println("YOU ARE NOW ADDING A MOTORBIKE");
                System.out.println("ENTER PLATE NUMBER");
                String plateNumber=sc.next();
                System.out.println("ENTER VEHICAL MODEL");
                String model=sc.next();
                System.out.println("ENTER VEHICAL MAKE");
                String make=sc.next();
                System.out.println("ENTER TYPE OF TRANSMISSION");
                String typeofTransmission=sc.next();
                System.out.println("ENTER THE VEHICLE YOU WANT IS RENTABLE OR NOT RENTABLE");
                String rentable=sc.next();
                System.out.println("ENTER TYPE OF MOTORBIKE");
                String typeofMoterbike=sc.next();
                System.out.println("ENTER DOES THE MOTORBIKE HAS STORAGE COMPARTMET OR NOT ");
                Boolean storageCompartment=sc.nextBoolean();
                MotorBike motorBike=new MotorBike();motorBike.setPlateNumber(plateNumber);motorBike.setModel(model);motorBike.setMake(make);motorBike.settypeofTransmission(typeofTransmission);motorBike.setrentable(rentable);motorBike.settypeofMoterbike(typeofMoterbike);motorBike.setstorageCompartment(storageCompartment);
                try{
                    String query2 = "insert into motorbike values(?,?,?,?,?,?,?)";
                    PreparedStatement insertState = connect.prepareStatement(query2);
                    insertState.setString(1, motorBike.getPlateNumber());
                    insertState.setString(2, motorBike.getMake());
                    insertState.setString(3,motorBike.getModel());
                    insertState.setString(4,motorBike.gettypeofTransmission());
                    insertState.setString(5,motorBike.getrentable());
                    insertState.setString(6,motorBike.gettypeofMoterbike());
                    insertState.setBoolean(7,motorBike.getstorageCompartment());
                    insertState.executeUpdate();}
                catch (Exception ex){
                    ex.printStackTrace();
                }}
        }
        if((no1+no2)==50){
            System.out.println("THERE IS NO MORE SPACE FOR PARKING");
        }
    }

    public void deleteVehicle() {
        boolean complete=true;
        int number = 0;
        String option="";
        Scanner myObject = new Scanner(System.in);
        while (number == 0) {
            System.out.println("TO DELETE A VEHICLE");
            System.out.println("ENTER 1 TO CAR OR 2 FOR MOTERBIKES");
            option=myObject.nextLine();
            if ((option.equals("1")) || (option.equals("2"))){
                number=1;
            }
            else{
                System.out.println("YOU ENTERED A WRONG VALUE ");
            }
        }
        if (option.equals("1")) {
            System.out.println("TO DELETE CAR");
            System.out.println("ENTER THE PLATE NUMBER");
            String plateNumber2 = myObject.nextLine();
            String query = "SELECT * FROM car ";
            try {
                rs = state.executeQuery(query);
                while (rs.next() && complete == true) {
                    String plateNumber1 = rs.getString("plateNumber");
                    if (plateNumber2.equals(plateNumber1)) {
                        complete = false;
                        //Displaying the all the in formation about the car the user entered before deleting
                        try {
                            String plateNumber = rs.getString("plateNumber").trim();
                            String model = rs.getString("model").trim();
                            String make = rs.getString("make");
                            String typeofTransmission= rs.getString("typeofTransmission").trim();
                            String rentable = rs.getString("rentable").trim();
                            int noofSeats = rs.getInt("noofSeats");
                            String noofSeats2=Integer.toString(noofSeats);
                            String airBags = rs.getString("airBags").trim();
                            String airCondition = rs.getString("airCondition").trim();
                            Car car=new Car();
                            car.setPlateNumber(plateNumber);
                            car.setModel(model);car.setMake(make);
                            car.settypeofTransmission(typeofTransmission);
                            car.setrentable(rentable);
                            car.setNoofSeats(noofSeats);
                            car.setairBags(airBags);
                            car.setairCondition(airCondition);
                            System.out.println(car.toString());
                            String query2 = "delete from cars where plateNumber= ?";
                            PreparedStatement deleteState = connect.prepareStatement(query2);
                            deleteState.setString(1, plateNumber);
                            deleteState.executeUpdate();
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }

        }
        if (option.equals("2")) {
            System.out.println("TO DELETE MOTORBIKE");
            System.out.println("ENTER THE PLATE NUMBER");
            String plateNumber2 = myObject.nextLine();
            String query = "SELECT * FROM motorbike ";
            try {
                rs = state.executeQuery(query);
                while (rs.next() && complete == true) {
                    String plateNumber1 = rs.getString("plateNumber");
                    if (plateNumber2.equals(plateNumber1)) {
                        complete = false;
                        try {
                            String plateNumber = rs.getString("plateNumber").trim();
                            String model = rs.getString("model").trim();
                            String make = rs.getString("make");
                            String typeofTransmission= rs.getString("typeofTransmission").trim();
                            String rentable = rs.getString("rentable");
                            String typeofMoterbike = rs.getString("typeofMoterbike");
                            Boolean storageCompartment = rs.getBoolean("storageCompartment");
                            MotorBike motorBike=new MotorBike();
                            motorBike.setPlateNumber(plateNumber);motorBike.setModel(model);motorBike.setMake(make);motorBike.settypeofTransmission(typeofTransmission);motorBike.setrentable(rentable);motorBike.settypeofMoterbike(typeofMoterbike);motorBike.setstorageCompartment(storageCompartment);
                            System.out.println(motorBike.toString());
                            String query2 = "delete from motorbike where plateNumber= ?";
                            PreparedStatement deleteState = connect.prepareStatement(query2);
                            deleteState.setString(1, plateNumber);
                            deleteState.executeUpdate();
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }}}

    public void printVehicle() {
        Boolean complete=true;
        System.out.println("-----THAT ARE ALL OF THE VEHICLES------");
        String query = "SELECT * FROM motorbike ORDER BY motorbike.make";
        System.out.println("---------------");
        try {
            rs = state.executeQuery(query);
            while (rs.next() && complete == true) {
                try {
                    String plateNumber3 = rs.getString("plateNumber").trim();
                    String make = rs.getString("make").trim();
                    System.out.println(plateNumber3 + " " + make);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }}}
        catch (Exception ex) {
            ex.printStackTrace();}
        System.out.println("-----THAT ARE ALL OF THE MOTORBIKES ------");

        String query1 = "SELECT * FROM car ORDER BY car.make";
        try {
            rs = state.executeQuery(query1);
            while (rs.next() && complete == true) {
                try {
                    String plateNumber3 = rs.getString("plateNumber").trim();
                    String make = rs.getString("make").trim();
                    System.out.println(plateNumber3 + " " + make);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }}}
        catch (Exception ex) {
            ex.printStackTrace();}
        System.out.println("--------THAT ARE ALL OF THE CARS---------");

    }

}
