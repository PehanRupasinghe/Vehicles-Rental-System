package sample;

public class Schedule {
    private Date startDate;
    private Date endDate;

    public Schedule(Date startDate, Date endDate){
        this.endDate = endDate;
        this.startDate = startDate;

    }

    public void setendDate(Date dateObject) {
        this.endDate = dateObject;
    }

    public void setstartDate(Date dateObject) {
        this.startDate = dateObject;
    }

    public Date getendDate() {
        return endDate;
    }

    public Date getstartDate() {
        return endDate;
    }
}