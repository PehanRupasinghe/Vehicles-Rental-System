package sample;

public abstract class Vehicle {


    protected String plateNumber;
    protected String model;
    protected String make;
    protected String typeofTransmission;
    protected String rentable;


    public Vehicle(String plateNumber, String model, String make, String typeofTransmission, String rentable) {
        this.plateNumber = plateNumber;
        this.model = model;
        this.make = make;
        this.typeofTransmission = typeofTransmission;
        this.rentable = rentable;

    }

    public Vehicle() {

    }


    public void setPlateNumber(String plateNumber) {

        this.plateNumber = plateNumber;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public void setMake(String make) {
        this.make = make;
    }


    public void settypeofTransmission(String typeofTransmission) {
        this.typeofTransmission = typeofTransmission;
    }

    public void setrentable(String rentable) {
        this.rentable = rentable;
    }

    public String getPlateNumber() {
        return plateNumber;
    }

    public String getMake() {
        return make;
    }

    public String getModel() {
        return model;
    }

    public String gettypeofTransmission() {
        return typeofTransmission;
    }

    public String getrentable() {
        return rentable;
    }

    public String toString() {
        return "Plate number: " + getPlateNumber() + "model: " + getModel() + "typeofTransmission: " + getMake() + "Type Of Transmission: " + gettypeofTransmission() + "Is It Rentable: " + getrentable();
    }


}