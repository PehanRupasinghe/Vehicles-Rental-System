package sample;

public class MotorBike extends Vehicle {
    private String typeofMoterbike;
    private boolean storageCompartment;

    public MotorBike() {
    }

    public MotorBike(String typeofMoterbike, boolean storageCompartment) {
        super();
        this.typeofMoterbike = typeofMoterbike;
        this.storageCompartment = storageCompartment;

    }

    public MotorBike(String plateNumber, String model, String make, String typeofTransmission, String rentable, String typeofMoterbike, boolean storageCompartment) {

        this.plateNumber = plateNumber;
        this.model = model;
        this.make = make;
        this.typeofTransmission = typeofTransmission;
        this.rentable = rentable;
        this.typeofMoterbike = typeofMoterbike;
        this.storageCompartment = storageCompartment;
    }

    public void settypeofMoterbike(String typeofMoterbike) {
        this.typeofMoterbike = typeofMoterbike;
    }

    public void setstorageCompartment(boolean storageCompartment) {
        this.storageCompartment = storageCompartment;
    }

    public boolean getstorageCompartment() {
        return storageCompartment;
    }


    public String gettypeofMoterbike() {
        return typeofMoterbike;
    }


    @Override
    public String toString() {
        return "Type of motor bike: " + gettypeofMoterbike() + "Storage Compartment: " + getstorageCompartment() + super.toString();
    }
}